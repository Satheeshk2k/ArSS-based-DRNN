from Main import Technical_Indicators, Data_Augmentation


def process(dst):
    Feat = Technical_Indicators.extracting_features(dst)
    data,cls=Data_Augmentation.data_augment(Feat, dst)
    return data,cls

def processing(dts):
    data,lab=process(dts)
    return data,lab