import csv, numpy, random, sys
import Proposed_ArSS.run

def callmain(nodes, rounds, pop_size):

    # creating nodes
    def node_creation(x_value, y_value):
        for x in range(col_n + 1):  # x columns1
            for y in range(m[x]):  # y rows
                px = 50 + x * 60 + random.uniform(-20, 20)  # node in x-axis at px
                x_value.append(px)
                py = 50 + y * 60 + random.uniform(-20, 20)  # node in y-axis at py
                y_value.append(py)

    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt((numpy.square(x_value[p2] - x_value[p1])) + (numpy.square(y_value[p2] - y_value[p1])))
        return dist

    # find the neighbours of each node
    def get_node_neighbours(x, y, n_nodes):
        neigh = []
        for i in range(n_nodes):    # for each node
            tem = []
            for j in range(n_nodes):    # find its neighbours
                if (i != j):
                    if (distance(i, j) < 100):
                        tem.append(j)   # nodes with min distance to the node is neighbour to that node
            neigh.append(tem)
        return neigh

    # initial energy generation
    def generate(v):
        data = []
        for i in range(nodes):
            data.append(v)  # initial energy of all nodes is 1
        return data

    # packets to be send by each node, mobility, direction
    def node_packet_speed_dir(nod):
        dp, ms, dm = [], [], []
        for i in range(rounds):
            tem_1, tem_2, tem_3 = [], [], []
            for j in range(nod):
                tem_1.append(random.randint(1, 10))
                tem_2.append(random.randint(1, 10))
                tem_3.append(random.uniform(0, (2*3.14))) # random(0, 2*pi)
            dp.append(tem_1)    # data packet
            ms.append(tem_2)    # mobility speed
            dm.append(tem_3)    # direction of motion
        return dp, ms, dm

    def view_bar(job_title, progress):
        length = 20  # modify this to change the length
        block = int(round(length * progress))
        msg = "\r{0}: [{1}] {2}%".format(job_title, "#" * block + "-" * (length - block), round(progress * 100, 2))
        if progress >= 1: msg += " DONE\r\n"
        sys.stdout.write(msg)
        sys.stdout.flush()


    # parameter initialization
    print("\nSystem model..")
    n_nodes = nodes + 1  # no. of nodes(+base station)
    SOURCE, BASE_STATION = 0, n_nodes-1  # source, destination(base station)

    # to place nodes over grid
    sq = int(numpy.sqrt(n_nodes))  # to make the nodes in square grid
    ex = n_nodes % sq  # excess nodes when make it square grid
    col_n = int((n_nodes - ex) / sq)  # columns for square grid
    m = []
    for i in range(col_n):
        m.append(sq)  # last column with excess nodes
    m.append(ex)

    data_packet, mobility_speed, direction = node_packet_speed_dir(nodes)    # packets send by each node & its speed
    Xt, Xr = 0.0005, 0.0005            # energy required to send, receive data
    Final_Energy, Final_Trust, Final_PDR, Final_Throughput = [], [], [], []         # Final energy,... of the nodes after all rounds
    Overall_Energy, Overall_Trust, Overall_PDR, Overall_Throughput = [], [], [], [] # each round energy,... of all methods
    simulation_result = []

    ################################################### Proposed: ArSS ################################################
    Energy, Trust, De= [], [], []
    Energy_avg, Trust_avg = [], []

    # initial values
    print("\t>> Energy model..")
    Energy.append(generate(1))
    Trust.append(generate(1))
    De.append(generate(0))
    print("\t>> Link Lifetime model..")
    print("\t>> Trust model..please wait..")
    print("\t>> Routing using ArSS Algorithm...")
    for i in range(rounds):
        view_bar("Selection Onprogress", i / (rounds - 1))
        x_value, y_value = [], []  # x & y value of each node
        node_creation(x_value, y_value)
        neighbours = get_node_neighbours(x_value, y_value, nodes)  # neighbour of node
        en, tr,de, SR = Proposed_ArSS.run.callmain(rounds,nodes, Trust[i], Energy[i], De[i],data_packet[i], x_value, y_value, BASE_STATION, i, Xt, Xr,
                                                        col_n, neighbours, pop_size,mobility_speed,direction,simulation_result)
        Energy.append(en)
        Trust.append(tr)
        De.append(de)
        Energy_avg.append(numpy.average(en))
        Trust_avg.append(numpy.average(tr))

    Overall_Energy.append(Energy_avg)
    Overall_Trust.append(Trust_avg)

    Final_Energy.append(Energy_avg[500])
    Final_Energy.sort()
    Final_Trust.append(Trust_avg[500])
    Final_Trust.sort()

    numpy.savetxt("Average Energy.csv", Overall_Energy, delimiter=',', fmt='%f')  # write data to csv file
    numpy.savetxt("Average Trust.csv", Overall_Trust, delimiter=',', fmt='%f')  # write data to csv file

    return Final_Energy, Final_Trust, SR