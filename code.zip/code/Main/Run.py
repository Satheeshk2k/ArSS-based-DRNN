from Main import routing, Process
import Proposed_ArSS_DRNN.ArSS
import time

dst='Dataset'
rounds=500
de=5000
MSE, RMSE,MAPE,Tr_t,ts_t = [], [],[],[],[]
nodes, pop_size = 150, 5  # No.of Nodes , Population size
Energy, Trust, SR = routing.callmain(nodes, rounds, pop_size)    # calling IoT routing
print("\n Preprocessing...")
st = time.time_ns()
Data, Label = Process.processing(dst)
print("\n Proposed ArSS based DRNN..")
Proposed_ArSS_DRNN.ArSS.optimize(dst,Data, Label, de, MSE, RMSE,MAPE,Tr_t,ts_t)
print("\n Done..")

