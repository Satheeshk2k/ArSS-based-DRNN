import random, numpy as np


def data_augment(input_data, dts):
    print("\t>> Data Augmentation...")
    total_instance = 25000  # existing rows + extra rows to be added (output with 25000 samples)
    def augment(data, ins_total):
        c_min, c_max = [], []  # column min & max
        for i in range(len(data[0])):  # for each feature
            col = np.array(data)[:, i]
            c_min.append(np.min(col))  # add min value
            c_max.append(np.max(col))  # add max value
        n_data = []
        for i in range(ins_total):  # data augmentation for feature
            tem = []
            for j in range(len(data[0])):
                if i >= len(data):
                    # for extra instance generate random b/w min & max of that feature
                    tem.append(random.uniform(c_min[j], c_max[j]))
                else:
                    tem.append(data[i][j])
            n_data.append(tem)
        data = np.row_stack((n_data,data))
        return data

    extra_added_data = augment(input_data, total_instance)
    extra_added_data = np.asarray(extra_added_data)
    Data = extra_added_data[:, 0:len(extra_added_data[0]) - 1]  # slicing data
    clas = extra_added_data[:, len(extra_added_data[0]) - 1]  # slicing label

    np.savetxt("Preprocessed//" + dts + "_data.csv", Data, delimiter=",", fmt="%s")
    np.savetxt("Preprocessed//" + dts + "_label.csv", clas, delimiter=",", fmt="%s")

    return Data,clas
