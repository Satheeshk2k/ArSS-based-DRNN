import math,numpy as np

# distance between nodes
def distance(p1, p2, x_value, y_value):
    dist = np.sqrt((np.square(x_value[p2] - x_value[p1])) + (np.square(y_value[p2] - y_value[p1])))  # distance formula
    return dist

def LLT(A, B, X, Y, m_spd, dom):
    XA, XB = X[A], X[B]  # X coordinates
    YA, YB = Y[A], Y[B]  # Y coordinates
    OA, OB = dom[A], dom[B]  # direction of motion
    VA, VB = m_spd[A], m_spd[B]  # mobility speed
    a, b = (VA * math.cos(OA) - VB * math.cos(OB)), (XA - XB)
    c, d = (VA * math.sin(OA) - VB * math.sin(OB)), (YA - YB)
    r, l = distance(A, B, X, Y), 1  # transmission range, link
    x = (a ** 2 + c ** 2)
    LLT = (-(a * b + c * d) + (
                np.abs((a ** 2 + c ** 2) * r ** 2 - (a * d - c * b) ** 2) ** (1 / 2))) / x  # LLT formula
    return LLT

def link_lifetime_cal(nodes,x,y,m_s,dir):
    lt=0
    for i in range(len(nodes)-1):
        lt+= LLT(nodes[i],nodes[i+1],x,y,m_s,dir) # Link lifetime between ith and jth node
    return lt


def dist_cal(nodes,x_v,y_v):
    D = 0
    for i in range(len(nodes)-1):
        D += distance(nodes[i],nodes[i+1],x_v,y_v) # Distance between ith and jth node
    return D

def energy_cal(nodes,en):
    en_ = 0
    for i in range(len(nodes)-1):
        en_ += en[nodes[i]] # en-->energy consumption in the ith node
    E = 1-en_
    return E


def fit_func(soln_nodes, en, xv, yv,m_speed,dir,Trust):
    fit=[]
    for i in range(len(soln_nodes)):
        E = energy_cal(soln_nodes[i],en) # Energy
        D = dist_cal(soln_nodes[i],xv,yv) # Distance
        L = link_lifetime_cal(soln_nodes[i],xv,yv,m_speed[i],dir[i]) # Link lifetime
        T= Trust[i] # Trust
        F = (E+L+(1-D)+T)/4 # Fitness Formula
        fit.append(F)
    return fit