import random,numpy as np
import pandas as pd
import pandas_ta as ta


def process(dts):
    data = np.array(pd.read_csv(r'dataset',header=None))
    datas = []
    for i in range(len(data)):
        temp = []
        for j in range(len(data[i])):
            if data[i][j] == '':  # replace '' by '-1000'
                data[i][j] = '-1000'
            temp.append(float(data[i][j]))
        datas.append(temp)
    n_data = []
    for i in range(len(data)):
        temp = []
        for j in range(len(data[i])):
            if (data[i][j] != '-1000'):  # except -1000 add all other values to a list
                temp.append(float(data[i][j]))
            else:
                temp.append(0)
        n_data.append(temp)
    n_data = np.array(n_data)
    Avg = np.mean(n_data, axis=0)  # average of column values
    for i in range(len(data)):
        for j in range(len(data[i])):
            if (data[i][j] == '-1000'):  # replace '-1000' by calculated average values
                data[i][j] = float(Avg[j])
            else:
                data[i][j] = float(data[i][j])
    data = np.array(data)
    np.savetxt("Preprocessed//" + dts + ".csv", data, delimiter=",", fmt="%s")

def extracting_features(dts):
    print("\t>> Technical Indicators...")
    data=process(dts) # preprocess
    feat =[]
    dta = pd.DataFrame(data=data, columns=["price"])  # setting the column as price in the dataframe
    #### converting numpy array to dataframe ####
    a = []  # High price
    for i in range(len(data)):
        a.append(float(data[i]) + 1)
    nn = np.column_stack((data, a))
    b = []  # Low price
    for i in range(len(data)):
        b.append(float(data[i]) - 1)
    nnn = np.column_stack((nn, b))
    c = []  # Close price
    for i in range(len(data)):
        l = float(data[i]) - 1
        h = float(data[i]) + 1
        c.append(random.uniform(l, h))
    new = np.column_stack((nnn, c))  # joining High, low , Close price
    df = pd.DataFrame(data=new, columns=["price", "High", "Low", "Close"])  # creating dataframe

    ############ TECHNICAL INDICATORS ###########
    EMA = ta.ema(df['Close']) # EMA
    DEMA = ta.dema(df['Close']) # DEMA
    ADM = ta.adx(df['High'], df['Low'], df['Close'])['ADX_14'] # ADM
    RSI = ta.rsi(df['Close'])  # Relative Strength Index
    ROC = ta.roc(df['Close']) # ROC
    ATR = ta.atr(df['High'], df['Low'], df['Close'])  # Average True Range
    Stochiastic = ta.stoch(df['High'], df['Low'], df['Close'])['STOCHk_14_3_3']

    ddf = pd.concat([EMA,DEMA,ADM,RSI,ROC,ATR,Stochiastic,dta], axis=1)
    ddf = ddf.fillna(ddf.mean())
    dataa = np.transpose(np.asarray(ddf)).tolist() # transposing the dataa
    for ii in range(len(dataa)): feat.append(dataa[ii]) # adding the extracted features in an empty list

    Feature = np.transpose(feat) # Transposing the feature and converting it to a list
    np.savetxt("Preprocessed//Feature_"+dts+".csv", Feature, delimiter=",", fmt="%s")
    return Feature

