def train_test_split(de, xx, yy): # train test split on basis of delay
    x_train = xx[:de]
    x_test = xx[de:]
    y_train = yy[:de]
    y_test = yy[de:]
    return x_train, x_test, y_train, y_test
