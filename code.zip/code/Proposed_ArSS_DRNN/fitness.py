from Proposed_ArSS_DRNN import DRNN

def func(dts,soln,xx,yy,tr,mse,rmse,mape,tr_t,st,ts_t):
    fit=[]
    for i in range(len(soln)):
        Mse,Rmse = DRNN.classify(dts,xx,yy,tr,mse,rmse,mape,tr_t,st,ts_t)
        fit.append(Mse)
    return fit