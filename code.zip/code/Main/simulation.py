import random
import wsnsimpy.wsnsimpy_tk as wsp

def run(x_value, y_value, rounds, BS, col_n, dead_nodes, Final_path):

    class MyNode(wsp.Node):
        tx_range = 50

        ###################
        def run(self):  # loop until nodes
            yield self.timeout(1)  # shows created nodes

            for i in range(len(x_value)):   # n_nodes
                if self.id is source:
                    self.scene.nodecolor(self.id, 0, 0, 1)  # if source node, node color => blue
                    self.scene.nodewidth(self.id, 2)


                else:
                    if self.id is BS:
                        self.scene.nodecolor(self.id, 1, 0, 0)  # if node is Base station, node color => red
                        self.scene.nodewidth(self.id, 2)
                    else:
                        self.scene.nodecolor(self.id, 0, .9, 0)  # else, other node color => green

                for i in range(len(dead_nodes)):  # dead node will be disabled
                    if self.id is dead_nodes[i]:
                        self.scene.nodecolor(self.id, .7, .7, .7)  # node color => grey (disable)


            for i in range(len(Final_path) - 1):
                if self.id is Final_path[i]:
                    self.scene.nodecolor(self.id, 0, 0, 1)  # node color => blue
                    self.start_process(self.start_send_data(Final_path[i + 1]))  # source, destination

        ###################
        def start_send_data(self, dest):
            seq = 0

            while True:
                yield self.timeout(0.2)  # transmission will be displayed after 0.5s
                self.scene.clearlinks()
                d = random.uniform(.3, .9)  # uniform value between 0.3 - 0.9
                yield self.timeout(d)  # timeout of the link between nodes
                self.send_data(dest)  # source, dest
                seq += 1

        ###################
        def send_data(self, dest):
            self.send(dest, msg='data', src=self.id)

    source = 0
    WS = col_n * 70  # window size

    # simulation will display for 15s
    sim = wsp.Simulator(until=15, timescale=1, visual=True, terrain_size=(WS, WS), title="@ Round " + str(
        rounds))  # simulation window (15s,True - to display, ter -- wnd. size, tit -- wnd. title)

    for i in range(len(x_value)):  # x columns1
        px, py = x_value[i], y_value[i]
        node = sim.add_node(MyNode, (px, py))  # create node at (px,py)

    # start the simulation
    sim.run()