# Imports PIL module
from PIL import Image

# open method used to open different extension image file
im1 = Image.open(r"graphs\1.jpeg")
im2 = Image.open(r"graphs\2.jpeg")
im3 = Image.open(r"graphs\3.jpeg")
im4 = Image.open(r"graphs\4.jpeg")
im5 = Image.open(r"graphs\5.jpeg")
im6 = Image.open(r"graphs\6.jpeg")
im7 = Image.open(r"graphs\7.jpeg")
im8 = Image.open(r"graphs\8.jpeg")
im9 = Image.open(r"graphs\9.jpeg")
im10 = Image.open(r"graphs\10.jpeg")
im11 = Image.open(r"graphs\11.jpg")
im12 = Image.open(r"graphs\12.jpg")
im13 = Image.open(r"graphs\13.jpg")

# This method will show image in any image viewer
im1.show()
im2.show()
im3.show()
im4.show()
im5.show()
im6.show()
im7.show()
im8.show()
im9.show()
im10.show()
im11.show()
im12.show()
