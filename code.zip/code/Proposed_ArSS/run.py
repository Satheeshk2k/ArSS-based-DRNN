import numpy, random, math
from Proposed_ArSS import ArSS


def callmain(roundss,nodes, Trust, energy, delay,data_pack, x_value, y_value, BASE_STATION, i, xt, xr,
                                                        col_n, neighbours, pop,mobility_speed,direction,simulation_result):

    # distance between nodes
    def distance(p1, p2):
        dist = numpy.sqrt((numpy.square(x_value[p2] - x_value[p1])) + (numpy.square(y_value[p2] - y_value[p1])))
        return dist

    # calculate node energy
    def calc_node_en(np, prev_en, x_t, x_r):

        en = prev_en.copy()  # copy of previous round energy
        m, n = 0.0005, 1000  # normalizing factor
        # energy drop for all nodes
        for ed in range(len(np) - 1):
            y = data_pack[np[ed]]  # no. of transmitted bits
            if ed == 0:  # source node
                if en[np[ed]] > 0:
                    dt = distance(np[ed], np[ed + 1]) / n  # distance to send the data
                    E = en[np[ed]] - (x_t * y) * dt  # only send the data to head
                    if E > 0:
                        en[np[ed]] = E
                    else:
                        en[np[ed]] = 0
                else:
                    en[np[ed]] = 0

            else:  # other nodes in path
                if np[ed] > 0:  # if 0 then no path
                    if en[np[ed]] > 0:
                        dt, dr = distance(np[ed], np[ed + 1]) / n, distance(np[ed], np[
                            ed - 1]) / n  # distance to send & receive the data
                        E = en[np[ed]] - (x_r * y) * dr - (x_t * y) * dt  # receive & send
                        if E > 0:
                            en[np[ed]] = E
                        else:
                            en[np[ed]] = 0
                    else:
                        en[np[ed]] = 0
        return en


    # calculate Trust
    def T_Beta(en, data, o_t):

        n_packet, packet_received = 0, 0  # total packets, packets received
        for i in range(len(en)):  # to the size of the node
            n_packet = n_packet + data[i]
            packet_received += en[i] * data[i]
            old_trust = o_t[i]
        alpha = packet_received  # No.of successfull interaction
        beta = n_packet - packet_received  # No.of unsuccessful interaction
        Teta = random.random()  # aging factor
        w = random.random()  # weight
        sigma = 0.5  # sigma
        uij = (12 * alpha * beta) / (((alpha + beta) ** 2) * (1 + alpha + beta))
        bij = (alpha / (alpha + beta)) * (1 - uij)
        New_trust = bij + sigma * uij
        T_Beta = w * New_trust + Teta * (1 - w) * old_trust
        Final_trust = T_Beta
        return Final_trust

    def T_Belief(n, nodes, dp, neigh, de):
        e = []
        for ii in range(n):
            e.append(random.random())
        B = []  # Behaviour
        for i in range(nodes):
            b = 0
            for j in range(n):
                b += e[j]
            b_ = b / n
            B.append(b_)
        rb = 0
        for i in range(len(B)):
            rb += B[i]
        RB = rb / len(B)  # Average Behaviour
        # Direct
        DT = []
        for i in range(n):  # to the size of the node
            DT.append(((1.0 - de[i]) * dp[i]) / dp[i])
        NF = 2
        # InDirect
        InDT = []
        for i in range(n):
            indir = 0
            for j in range(len(neigh[i])):  # neighbour nodes
                indir += DT[neigh[i][j]]  # trust of neighbour nodes
            a = len(neigh[i])
            if a<=0 : a= 1
            InDT.append(indir / a)
        beta = 0.5
        U = []
        for i in range(nodes):
            U.append((beta * DT[i]) + ((1.0 - beta) * InDT[i]))

        T_B = (numpy.mean(B) + RB + numpy.mean(U))/NF
        return T_B

    def trust_cal(en, data_pack, o_t, nodes, neigh, delay):
        T=[]
        for i in range(nodes):
            T_Bet = T_Beta(en, data_pack, o_t)  # Trust Beta
            N_pack = len(data_pack)
            T_Bel = T_Belief(N_pack, nodes, data_pack, neigh, delay)  # Trust Belief
            T.append((T_Bet + T_Bel) / 2)
        return T

    # Pth detection
    def detection(opt_nodes, base, en, de, pop, n_c, nodes, data_pack,neigh,Trust):

        pth = []
        pth.append(0)  # source
        if (n_c > len(opt_nodes)): n_c = len(opt_nodes)  # non dead nodes

        # Path detection by Proposed Autoregressive Squirrel Search Alg.
        opt_path = ArSS.algm(opt_nodes, pop, en, x_value, y_value,nodes,mobility_speed,direction,Trust)
        for op in range(len(opt_path)):
            pth.append(opt_path[op])

        pth.append(base)  # destination
        pth = numpy.unique(pth)
        pth.sort()
        return pth.tolist()

    # nodes other than dead nodes
    def get_active_nodes(en):
        opt_n = []
        for o in range(len(en)):
            if (o > 0) and (en[o] > 0):  # node with energy(not the dead node)
                opt_n.append(o)  # nodes other than source & destination
        return opt_n

    # get non dead nodes
    opt_nodes = get_active_nodes(energy)
    # Path from source to destination
    round_energy, round_delay, round_trust = energy.copy(), delay.copy(),Trust.copy()
    n_cluster=4
    if (len(opt_nodes) > 0):
        path = detection(opt_nodes, BASE_STATION, energy, delay, pop, n_cluster, nodes, data_pack,neighbours,Trust)
        round_energy = calc_node_en(path, energy, xt, xr)  # energy of nodes after the transmission
        round_trust = trust_cal(energy,data_pack,Trust,nodes,neighbours,delay)
    # results for simulation
    # results for simulation
    if (i == 500):  # at round 500
        dead_node = []  # nodes with no energy
        for j in range(len(round_energy)):
            if (round_energy[j] == 0):
                dead_node.append(j)

        simulation_result.append(x_value)  # nodes x-axis value
        simulation_result.append(y_value)  # nodes y-axis value
        simulation_result.append(roundss)  # no. of rounds
        simulation_result.append(BASE_STATION)  # Base station
        simulation_result.append(col_n)  # no. of grid columns in simulation window
        simulation_result.append(dead_node)  # dead nodes (nodes with energy 0)
        simulation_result.append(path)  # transmission path of last node
    return round_energy, round_trust,round_delay, simulation_result
